<?php

class Admin_Con extends Controller{
	
}