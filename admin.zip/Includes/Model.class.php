<?php
//Module.class.php

/**
* 	@filesource Module
*/
class Model extends Sqli
{
	protected $table       = "";
	protected $result      = array();
	protected $fatchedRows = 0;

	public function getSource($catId){

	}

}
